# Assembla-api-invested-hours-tracker-
Desktop app build in WinForms using c# which let's you track your work time and post it on assembla's web site with the help of their api. you can post comments as well by this app.

<a target="_blank" href="http://radikal.ru/big/787e50249f404853a5235a6b8829ebf6"><img src="http://s017.radikal.ru/i401/1603/00/0245389fad77.jpg" ></a>
