
Imports System.Globalization

Public Class MainForm
    Private currentDate As Date = Date.Today

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCalendar(currentDate.Year, currentDate.Month)
    End Sub

    Private Sub LoadCalendar(year As Integer, month As Integer)
        CalendarPanel.Controls.Clear()
        Dim firstDay As New Date(year, month, 1)
        Dim daysInMonth As Integer = Date.DaysInMonth(year, month)
        Dim dayOfWeek As Integer = CInt(firstDay.DayOfWeek)
        If dayOfWeek = 0 Then dayOfWeek = 7 ' Domenica = 7

        Dim row As Integer = 0
        Dim col As Integer = dayOfWeek - 1

        For i As Integer = 1 To daysInMonth
            Dim dayButton As New Button()
            dayButton.Text = i.ToString()
            dayButton.Tag = New Date(year, month, i)
            dayButton.Width = 90
            dayButton.Height = 70
            dayButton.Margin = New Padding(2)
            AddHandler dayButton.Click, AddressOf DayButton_Click

            Dim totalHours = DBHelper.GetTotalHoursForDate(New Date(year, month, i))
            If totalHours > 0 Then
                dayButton.Text &= vbCrLf & $"{totalHours:N1}h"
            End If

            CalendarPanel.Controls.Add(dayButton, col, row)

            col += 1
            If col > 6 Then
                col = 0
                row += 1
            End If
        Next
    End Sub

    Private Sub DayButton_Click(sender As Object, e As EventArgs)
        Dim btn As Button = CType(sender, Button)
        Dim day As Date = CType(btn.Tag, Date)

        Dim f As New TimbratureForm(day)
        f.ShowDialog()
        LoadCalendar(day.Year, day.Month)
    End Sub
End Class
